package main.scala

import main.scala.obj.Dictionary
import main.scala.obj.Document
import main.scala.helper.LDACmdOption
import main.scala.obj.Parameter
import main.scala.helper.Utils

object ScalaSourceLDA {
  def main(args: Array[String]): Unit = {
    println("#################### Source LDA ####################")
    try {
      var cmd = LDACmdOption.getArguments(args)
      if (cmd.hasOption("help")) {
        LDACmdOption.showHelp()
      } else {
        // set user parameters
        var params = new Parameter
        params.getParams(cmd)
        if (!params.checkRequirement) {
          println("ERROR!!! Phai nhap day du cac tham so: alpha, beta, directory, datafile, ksfile, ntopics, niters")
          LDACmdOption.showHelp()
          return
        } else {

          //~~~~~~~~~~~ Timer ~~~~~~~~~~~
          val startTime = System.currentTimeMillis()

          //~~~~~~~~~~~ Body ~~~~~~~~~~~

          var inferencer = new Inferencer()
          println("Preparing...")
          inferencer.init(params)
          println("Inferencing...")
          var newModel = inferencer.inference(params)

          for (i <- 0 until newModel.phi.length) {
            //phi: K * V
            println("-----------------------\nTopic " + (i + 1) + "th: ")
            Utils.printTopWords(i, newModel.V, newModel.phi, newModel.data, 10)
          }
        }
      }
    } catch {
      case e: Throwable => e.printStackTrace()
    }
  }
}
